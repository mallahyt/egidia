<?php
require 'function.php';

$mhs = query("SELECT * FROM mhs");

    //koneksi db
    $server = "localhost";
    $user = "root";
    $pass = "";
    $database = "biodata";

    $conn = mysqli_connect($server, $user, $pass, $database)or die(mysqli_error($conn));

    //jika tombol simpan di klik
    if(isset($_POST['bsave']))
    {
        //Pengujian Apakah data akan diedit atau disimpan baru
        if($_GET['hal'] == "edit")
        {
			//Data akan di edit
			$edit = mysqli_query($conn, "UPDATE mhs set
											 	nim = '$_POST[tnim]',
											 	name = '$_POST[tname]',
												address = '$_POST[taddress]',
											 	status = '$_POST[tstatus]',
                                                blood = '$_POST[tblood]',
												gender = '$_POST[tgender]',
											 	birthday = '$_POST[tbirthday]',
                                                photo = '$_POST[tphoto]'
											 WHERE id_mhs = '$_GET[id]'
										   ");
			if($edit) //jika edit sukses
			{
				echo "<script>
						alert('Edit data suksess!');
						document.location='indexs.php';
				     </script>";
			}
			else
			{
				echo "<script>
						alert('Edit data GAGAL!!');
						document.location='indexs.php';
				     </script>";
			}
        }
	    else
        {
            //simpan data baru
            $save = mysqli_query($conn, "INSERT INTO mhs (nim, name, address, status, blood, gender, birthday, photo)
                                            VALUES ('$_POST[tnim]',
                                                    '$_POST[tname]',
                                                    '$_POST[taddress]',
                                                    '$_POST[tstatus]',
                                                    '$_POST[tblood]',
                                                    '$_POST[tgender]',
                                                    '$_POST[tbirthday]',
                                                    '$_POST[tphoto]')
                                        ");
            if($save)
            {
                echo "<script>
                    alert('Success!');
                    document.location='indexs.php';
                </script>";
            }
            else
            {
                echo "<script>
                alert('Failed!');
                document.location='indexs.php';
                </script>";
            }
        }
    
    }


    //Pengujian jika tombol Edit / Hapus di klik
	if(isset($_GET['hal']))
	{
		//Pengujian jika edit Data
		if($_GET['hal'] == "edit")
		{
			//Tampilkan Data yang akan diedit
			$tampil = mysqli_query($conn, "SELECT * FROM mhs WHERE id_mhs = '$_GET[id]' ");
			$data = mysqli_fetch_array($tampil);
			if($data)
			{
				//Jika data ditemukan, maka data ditampung ke dalam variabel
				$vnim = $data['nim'];
				$vname = $data['name'];
				$vaddress = $data['address'];
                $vstatus = $data['status'];
                $vblood = $data['blood'];
				$vgender = $data['gender'];
				$vbirthday = $data['birthday'];
				$vphoto = $data['photo'];
			}
		}
		else if ($_GET['hal'] == "delete")
		{
			//Persiapan hapus data
			$delete = mysqli_query($conn, "DELETE FROM mhs WHERE id_mhs = '$_GET[id]' ");
			if($delete){
				echo "<script>
						alert('Delete Successed !!');
						document.location='indexs.php';
				     </script>";
			}
		}
	}
  
?>

<!DOCTYPE html>
<html>
<head>
        <title>PERSONAL IDENTIFY</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
<div class="container">

    <h1 class="text-center">PERSONAL IDENTIFY FORM</h1>
    <h4 class="text-center">light_finger</h4>

    <!--First Card Form-->
    <div class="card mt-3">
     <div class="card-header bg-primary text-white">
        Input Your Data Here!
     </div>
     <div class="card-body">
        <form methode="post" action="">
            <div class="form-group">
                <label>NIM</label>
                <input type="text" name="tnim" value="<?=@$vnim?>" class="form-control" placeholder="Input Nim!" required>
                </div>    

            <div class="form-group">
                <label>NAME</label>
                <input type="text" name="tname" value="<?=@$vname?>" class="form-control" placeholder="Input Name!" required>
            </div>  

            <div class="form-group">
                <label>ADDRESS</label>
                <textarea class="form-control" name="taddress" value="<?=@$vaddress?>" placeholder="Input Address!" required>
                </textarea>
            </div>  

            <div class="form-group">
                <label>STATUS</label>
                <input type="text" name="tstatus" value="<?=@$vstatus?>"  class="form-control" placeholder="Input Status!" required>
            </div>  

            <div class="form-group">
                <label>BLOOD &nbsp;&nbsp;</label>
                <select class="form-control" name="tblood">
                    <option value="<?=@$vblood?>"><?=@$vblood?></option>
                    <option value="A">A</option>
                    <option value="B">B</option>                 
                    <option value="O">O</option>
                    <option value="AB">AB</option>
                </select>
            </div>  

            <div class="form-group">
                <label>GENDER &nbsp;&nbsp;</label>
                <select class="form-control" name="tgender">
                <option value="<?=@$vgender?>"><?=@$vgender?></option>
                <option value="Man">Man</option>
                <option value="Woman">Woman</option>
            </div>  

            <div class="form-group">
                <label>BIRTHDAY</label>
                <input type="date" name="tbirthday" value="<?=@$vbirthday?>">
            </div>  

            <div class="form-group">
                <label>PHOTO</label>
                <input type="file" name="tphoto" value="<?=@$vphoto?>">
            </div> 

            <button type="submit" class="btn btn-success" name="bsave">Save</button> 
            <button type="reset" class="btn btn-danger" name="breset">Reset</button> 
            
        </form>
         </div>
    </div>
    <!--Last Card Form-->
    
    <!--First Card Table-->
    <div class="card mt-3">
      <div class="card-header bg-danger text-white">
        LIST PERSON
      </div>
      <div class="card-body">

        <table class="table table-bordered table-striped">
                <tr>
                    <th>No</th>
                    <th>Nim</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Status</th>
                    <th>Blood</th>
                    <th>Gender</th>
                    <th>Birthday</th>
                    <th>Photo</th>
                    <th>action</th>
                </tr>
            <?php
                $no = 1;
                $tampil = mysqli_query($conn, "SELECT * from mhs order by id_mhs desc");
                while($data = mysqli_fetch_array ($tampil)) :
            ?>
            <tr>
                <th><?=$no++?></th>
                <th><?=$data['nim']?></th>
                <th><?=$data['name']?></th>
                <th><?=$data['address']?></th>
                <th><?=$data['status']?></th>
                <th><?=$data['blood']?></th>
                <th><?=$data['gender']?></th>
                <th><?=$data['birthday']?></th>
                <th><?=$data['photo']?></th>
                <td>
                    <a href="indexs.php?hal=edit&id=<?=$data['id_mhs']?>" class="btn btn-warning"> Edit </a>
                    <a href="indexs.php?hal=delete&id=<?=$data['id_mhs']?>"
                        onclick="return confirm('Delete This Data?')" class="btn btn-danger"> Delete </a>
                </td>
            <tr>
        <?php endwhile; ?>
        </table>

      </div>
    </div>
    <!--Last Card Table-->

    </div>

    <script type="text/javascript" src="js//bootstrap.min.js"></script>
</body>
</html>