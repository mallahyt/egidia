<?php

$conn = mysqli_connect("localhost", "root", "", "biodata");

function query($query){
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while ( $row = mysqli_fetch_assoc($result) ){
        $rows[] = $row;
    }
    return $rows;
}

function save($data) {
    global $conn;
    $nim = htmlspecialchars($data["nim"]);
    $name = htmlspecialchars($data["name"]);
    $address = htmlspecialchars($data["address"]);
    $status = htmlspecialchars($data["status"]);
    $blood = htmlspecialchars($data["blood"]);
    $gender = htmlspecialchars($data["gender"]);
    $birthday = htmlspecialchars($data["birthday"]);
    $photo = htmlspecialchars($data["photo"]);


    $query = "INSERT INTO biodata
                VALUES
                ('', '$nim', '$name', '$address', '$status', '$blood', '$gender', '$birthday', '$photo')
             ";
    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}

?>
