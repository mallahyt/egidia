USE bio;

CREATE DATABASE biodata;
USE biodata;
CREATE TABLE (
id_mhs INT, 
nim INT,
NAME VARCHAR (100),
address VARCHAR (200),
STATUS VARCHAR (100),
blood VARCHAR(10),
gender VARCHAR(20),
birthday DATE,
photo VARCHAR (250),
PRIMARY KEY (id_mhs))

INSERT INTO mhs VALUES(1,'19156','yuki','akihabara','mhs','A','Woman','20-09-2001','ini.jpg')

INSERT INTO mhs VALUES(2,'19157','yui','konoha','ninja','B','Man','20-08-2000','itu.jpg')
